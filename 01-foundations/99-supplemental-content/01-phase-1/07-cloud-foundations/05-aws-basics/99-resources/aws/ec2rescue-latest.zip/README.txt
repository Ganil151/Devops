AWS EC2Rescue for Windows
=====================

Version
=======
1.1.5.3  - Added Log collection for MGN / DRS
1.1.5.2  - Added Support for EC2Launch v2
1.1.5.1  - Support IMDSv2 and NVMe drivers 
1.1.5    - Added Log collection for CloudEndure / SSM Logs
1.1.4    - Support C5/M5 Instance types
1.1.3.1  - Support online-mode for Windows Environment
1.1.2    - Support for command line interface
1.0.12   - Support for Windows Server 2016 password reset
1.0.10.2 - Initial public release


Prerequisites
=============
*** Offline Instance Mode Requirements ***
1. An EC2 Instance with the following specifications:
    a. Windows 2008 R2 thru 2016
    b. .Net Framework 3.5 SP1 or later installed
    c. Located in the same Availability Zone as the inoperable instance
    d. Can be connected to through RDP
2. The offline root volume of the impaired/unreachable Windows 2008 thru 2016 instance attached to the functional instance(mentioned above) as a secondary volume
    Note: Windows 2008 R1 is supported for offline instance analysis only.
3. Current copy of EC2Rescue from https://s3.amazonaws.com/ec2rescue/windows/EC2Rescue_latest.zip

*** Current Instance Mode Requirements ***
1. A Windows Server with the following specifications:
    a. Windows 2008 R2 thru 2016
    b. .Net Framework 3.5 SP1 or later installed
    c. Can be connected to through RDP or console
        Note: Windows 2008 R1 is supported for offline instance analysis only.
2. Current copy of EC2Rescue from https://s3.amazonaws.com/ec2rescue/windows/EC2Rescue_latest.zip


Before You Start
================
- If you intend to use this tool's [Offline Instance] mode, you must first attach an offline instance volume to your helper instance.
** Note: We strongly recommend that customers create a snapshot of their impaired/unreachable instance's root volume to back it up, before proceding with this process

- An offline instance volume is the root volume of an impaired/unreachable instance, that has been connected as a secondary volume to a helper instance for offline troubleshooting of the impaired/unreachable OS.

- A helper instance is a healthy Windows Server 2008 R2 or later instance, that you can RDP to and run EC2Rescue on. Theoretically, you should be reading this help file from your helper instance

- For instructions on how to attach the offline root volume to your helper instance, please see the included EC2Rescue.chm help system file or visit our docs at the following links:

Detaching an Amazon EBS Volume from an Instance
http://docs.aws.amazon.com/es_es/AWSEC2/latest/WindowsGuide/ebs-detaching-volume.html

Attaching an Amazon EBS Volume to an Instance
http://docs.aws.amazon.com/es_es/AWSEC2/latest/UserGuide/ebs-attaching-volume.html


Running EC2Rescue for Windows
============
- No installation of this tool is necessary.
- Ensure that your instance meets the requirements and have connected any offline volumes to be troubleshooted.
- Start the tool, by double-clicking the EC2Rescue.exe application file
- Details of its operation can be found in the included EC2Rescue.chm help system


Version Notes
============
++++++++++++++++++++++++++++++++++++++++++++++++
Version: 1.1.5.3
Release date: 2024-09-02
Note:
- Added MGN / DRS log files on log collection

++++++++++++++++++++++++++++++++++++++++++++++++
Version: 1.1.5.2
Release date: 2023-09-28
Note:
- Added Support for Password reset via EC2Launch v2

++++++++++++++++++++++++++++++++++++++++++++++++
Version: 1.1.5.1
Release date: 2023-08-31
Note:
- Added IMDSv2 support
- Added NVMe drivers support
- Minor bug fixes

++++++++++++++++++++++++++++++++++++++++++++++++
Version: 1.1.5
Release date: 2021-02-18
Note:
- Added CloudEndure / SSM log files on log collection
- Minor bug fixes

++++++++++++++++++++++++++++++++++++++++++++++++
Version: 1.1.4
Release date: 2018-05-22
Note:
- Support C5/M5 Instance types
- Minor bug fixes

++++++++++++++++++++++++++++++++++++++++++++++++
Version: 1.1.3.1
Release date: 2018-03-12
Note:
- Support online-mode for Windows environment
- Added ECS log files on log collection
- Minor bug fixes

++++++++++++++++++++++++++++++++++++++++++++++++
Version: 1.1.2
Release date: 2017-09-10
Note:
- Support for command line interface by EC2RescueCmd.exe
- Added Elastic GPU instance files on log collection
- Added gpresult on log collection
- Changed RealTimeIsUniversal check to treat the key not set as a warning rather than an information
- Fixed a bug when collecting Windows Update log on Windows Server 2016
- Fixed a bug when collecting logs on i3 instance type
- Fixed a bug when using EC2Rescue on non-English Environment
- Removed dependency on diskpart
- Minor bug fixes

++++++++++++++++++++++++++++++++++++++++++++++++
Version: 1.0.12
Release date: 2017-03-31
Note:
- Support for Windows Server 2016 password reset
- Support for more detailed driver log collection
- Fixed bugs related to Windows Server 2016

++++++++++++++++++++++++++++++++++++++++++++++++
Version: 1.0.10.2
Release date: 2017-02-07
Note:
- Initial release version
- No applicable version notes


Known Issues
============
EC2Rescue cannot properly bring online or detect the Windows installation on connected offline root volumes that are configured as dynamic disks.
    *Use "Import foreign disks..." in Disk Management to bring the disk online, before selecting it in EC2Rescue [Offline instance mode]